package com.springdemo.springboot.springbootpractice;


import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@ConfigurationProperties(prefix = "service")
@Component
public class ServiceConfiguration {
    private String nickname;
    private int rank;
    private int jersey;

    public String getNickname() {
        return nickname;
    }

    public ServiceConfiguration setNickname(String nickname) {
        this.nickname = nickname;
        return this;
    }

    public int getRank() {
        return rank;
    }

    public ServiceConfiguration setRank(int rank) {
        this.rank = rank;
        return this;
    }

    public int getJersey() {
        return jersey;
    }

    public ServiceConfiguration setJersey(int jersey) {
        this.jersey = jersey;
        return this;
    }
}
