package com.springdemo.springboot.springbootpractice;


import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Arrays;
import java.util.List;

@RestController
public class CourseController {

    @RequestMapping("/cricketers")
    public List<Cricketers> retrieveAllCourses() {
        return Arrays.asList(
                new Cricketers(1,"Virat Kohli", "Bat"),
                new Cricketers(2,"AB De Villiers", "Bat/WK"),
                new Cricketers(3,"Mhd Siraj", "Bowl"),
                new Cricketers(4,"Ravindra Jadeja", "All-Rounder"),
                new Cricketers(5,"Rohith Sharma", "Bat")
        );
    }
}
